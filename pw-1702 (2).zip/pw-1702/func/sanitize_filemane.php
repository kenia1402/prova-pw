<?php

function sanitize_filemane($filemane) 
{
  
    $filemane = preg_replace('/[^a-zA-Z0-9_.]/', '', $filemane);
    return $filemane;
}