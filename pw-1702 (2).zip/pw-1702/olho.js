const olho = documents.getelementById('olho');
olho.addEventListener('click', () => {
    alert('Ali');
});