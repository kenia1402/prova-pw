<?php
    # /usuarios.php
    require('verifica_login.php');
    require('twig_carregar.php');
   
    require('models/Model.php');
    require('models/Usuario.php');

    $usr = new Produto();
    $usuarios = $usr->getAll();

    echo $twig->render('produto.html', [
        'produto' => $produto,
    ]);