<?php

require('twig_carregar.php');

echo $twig->render('documento.html');