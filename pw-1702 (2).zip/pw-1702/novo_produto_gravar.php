<?php
    # novo_usuario_gravar.php
    require('models/Model.php');
    require('models/Usuario.php');

    $produto = $_POST['Produto'] ?? false;
    $preco = $_POST['Preço'] ?? false;

    if (!$produto || !$preco) {
        header('location:novo_produto.php');
        die;
    }

    $pass = password_hash($pass, PASSWORD_BCRYPT);

    $usr = new Produto();
    $usr->create([
        'produto' => $produto,
        'preco' => $preco,
    ]);

    header('location:produtos.php');



