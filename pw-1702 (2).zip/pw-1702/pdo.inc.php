<?php
    # pdo.inc.php
    $pdo = new PDO('mysql:host=localhost;dbname=sistema_twig', 'root', '');