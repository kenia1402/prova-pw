<?php
class Usuario extends Model
{
  
}