<?php
class Produtos extends Model
{
  
}